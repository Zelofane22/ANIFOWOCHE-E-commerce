---
name: ⚙️ Tâche technique
about: Configuration, installation, mise en place d'infrastructure
title: "[TECH] Titre de la tâche"
labels: technique
assignees: ''
---

## ⚙️ Description

> Décris ce qu'il faut faire et pourquoi.

---

## ✅ Checklist

- [ ] Étape 1
- [ ] Étape 2
- [ ] Étape 3

---

## 📎 Informations

| Champ | Valeur |
|-------|--------|
| Sprint | Sprint ? |
| Temps estimé | ?h |
| Lié à la US | #? |

---

## 📝 Notes

> Documentation utile, commandes, liens...
