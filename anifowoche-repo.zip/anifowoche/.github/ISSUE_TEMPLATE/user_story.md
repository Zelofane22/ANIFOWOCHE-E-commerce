---
name: 📖 User Story
about: Nouvelle fonctionnalité du point de vue utilisateur
title: "[US-XX] Titre de la user story"
labels: user-story
assignees: ''
---

## 📖 User Story

> En tant que **[rôle]**, je peux **[action]** afin de **[bénéfice]**.

---

## ✅ Critères d'acceptation

- [ ] Critère 1
- [ ] Critère 2
- [ ] Critère 3

---

## 🛠️ Tâches techniques

- [ ] Tâche 1
- [ ] Tâche 2

---

## 📎 Informations

| Champ | Valeur |
|-------|--------|
| Epic | E? — Nom de l'epic |
| Sprint | Sprint ? |
| Priorité | P1 / P2 / P3 |
| Story points | ? pts |
| Temps estimé | ?h |

---

## 📝 Notes / Ressources

> Liens utiles, documentation, captures d'écran...
