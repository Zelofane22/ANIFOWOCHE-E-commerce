---
name: 🐛 Bug
about: Signaler un problème ou comportement inattendu
title: "[BUG] Titre du bug"
labels: bug
assignees: ''
---

## 🐛 Description du bug

> Décris clairement le problème observé.

---

## 🔁 Étapes pour reproduire

1. Aller sur '...'
2. Cliquer sur '...'
3. Observer '...'

---

## ✅ Comportement attendu

> Ce qui devrait se passer normalement.

---

## 📸 Capture d'écran / Log

> Colle ici une capture ou un message d'erreur si disponible.

---

## 🖥️ Environnement

| Champ | Valeur |
|-------|--------|
| Navigateur | Chrome / Firefox / Safari |
| Appareil | Desktop / Mobile |
| Version WordPress | |
| Plugin concerné | |
