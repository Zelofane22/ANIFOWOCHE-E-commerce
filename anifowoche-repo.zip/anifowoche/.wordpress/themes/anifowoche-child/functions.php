<?php
/**
 * ANIFOWOCHE Child Theme — functions.php
 * Chargement des styles du thème parent (Storefront) + enfant
 */

add_action( 'wp_enqueue_scripts', 'anifowoche_child_enqueue_styles' );

function anifowoche_child_enqueue_styles() {
    // Charger le style du thème parent Storefront
    wp_enqueue_style(
        'storefront-style',
        get_template_directory_uri() . '/style.css'
    );

    // Charger le style du thème enfant (écrase le parent)
    wp_enqueue_style(
        'anifowoche-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( 'storefront-style' ),
        wp_get_theme()->get( 'Version' )
    );
}
